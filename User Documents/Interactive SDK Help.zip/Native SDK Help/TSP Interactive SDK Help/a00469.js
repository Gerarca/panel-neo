var a00469 =
[
    [ "DeleteData", "a00469_a30f6daa8de928ae3560dcc33ce2f5b7b.html#a30f6daa8de928ae3560dcc33ce2f5b7b", null ],
    [ "InsertData", "a00469_a4fb921e99b052305d8b3d1d6b217c999.html#a4fb921e99b052305d8b3d1d6b217c999", null ],
    [ "SelectData", "a00469_a76d2d989f2ff8194dbe184e906f6d7ca.html#a76d2d989f2ff8194dbe184e906f6d7ca", null ],
    [ "UpdateData", "a00469_ae96422f0a4812bdfa3a7ff81d2b82d08.html#ae96422f0a4812bdfa3a7ff81d2b82d08", null ]
];