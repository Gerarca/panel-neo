var a00489 =
[
    [ "get_Length", "a00489_ad39197241c5ac37f8a6f81ae757c853e.html#ad39197241c5ac37f8a6f81ae757c853e", null ],
    [ "get_String", "a00489_a7f1b9c473b0afa920f8821028c175d15.html#a7f1b9c473b0afa920f8821028c175d15", null ],
    [ "set_String", "a00489_af60d0ce1afcd0fbcf65bc4287b082889.html#af60d0ce1afcd0fbcf65bc4287b082889", null ]
];