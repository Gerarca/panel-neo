var a00481 =
[
    [ "Clear", "a00481_ad347a12fa8c1ccff133c488af1a7c2ca.html#ad347a12fa8c1ccff133c488af1a7c2ca", null ],
    [ "get_DataState", "a00481_a267b7054c766b20ef799f54c05372078.html#a267b7054c766b20ef799f54c05372078", null ],
    [ "get_Protocol", "a00481_a5a755d66a3dc8d684a16faf4c4d83722.html#a5a755d66a3dc8d684a16faf4c4d83722", null ],
    [ "GetRawData", "a00481_abc689611f42f37076dff458b11711c96.html#abc689611f42f37076dff458b11711c96", null ],
    [ "GetRawSize", "a00481_a1b3ac87fbee23c1904de387d98778974.html#a1b3ac87fbee23c1904de387d98778974", null ],
    [ "SetRawData", "a00481_a343a5c29da848cdafc323091aab0b3cc.html#a343a5c29da848cdafc323091aab0b3cc", null ]
];